package com.demo.shipping.ShippingDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
